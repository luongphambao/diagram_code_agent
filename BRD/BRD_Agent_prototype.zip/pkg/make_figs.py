"""Sinh toàn bộ diagram cho BRD dự án diagram_code_agent.
Dùng mingrammer `diagrams` + Graphviz, style học thuật: nền trắng, 1 màu nhấn.
"""
import os
from diagrams import Diagram, Cluster, Edge, Node
from diagrams.onprem.client import Users, User, Client
from diagrams.onprem.database import PostgreSQL
from diagrams.onprem.compute import Server
from diagrams.onprem.network import Nginx
from diagrams.onprem.container import Docker
from diagrams.programming.framework import React, Fastapi
from diagrams.programming.language import Python
from diagrams.generic.storage import Storage
from diagrams.generic.compute import Rack
from diagrams.generic.blank import Blank
import diagrams.programming.flowchart as fc

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "figs")
os.makedirs(OUT, exist_ok=True)

FONT = "DejaVu Sans"
ACCENT = "#1F4E79"
GRAY = "#666666"

GRAPH = {
    "fontname": FONT, "bgcolor": "white", "fontsize": "20",
    "labelloc": "t", "pad": "0.4", "nodesep": "0.55", "ranksep": "0.85",
    "splines": "ortho",
}
NODE = {"fontname": FONT, "fontsize": "15"}
EDGE = {"fontname": FONT, "fontsize": "13", "color": GRAY}
CLU = {"fontname": FONT, "fontsize": "16", "bgcolor": "#F4F7FB",
       "pencolor": ACCENT, "style": "rounded", "penwidth": "1.2"}


def d(name, title, **kw):
    g = dict(GRAPH); g.update(kw.pop("graph_attr", {}))
    return Diagram(title, filename=os.path.join(OUT, name), outformat="png",
                   show=False, graph_attr=g, node_attr=NODE, edge_attr=EDGE, **kw)


# ── H1. Sơ đồ ngữ cảnh hệ thống ───────────────────────────────────────────────
with d("h1_context", "Hình 1 — Sơ đồ ngữ cảnh hệ thống (System Context)", direction="LR"):
    with Cluster("Người dùng nghiệp vụ (Business users)", graph_attr=CLU):
        ba = User("BA / Solution Architect")
        pm = User("Project Manager")
        cl = Users("Khách hàng (Client)")

    with Cluster("Diagram Code Agent Platform", graph_attr=CLU):
        ui = React("Web UI\n(React + AG-UI/SSE)")
        api = Fastapi("Agent API\n(FastAPI :8001)")
        agent = Rack("Deep Agent\n(LangGraph orchestrator)")
        ui >> Edge(label="SSE stream") >> api >> agent

    with Cluster("Dịch vụ ngoài (External services)", graph_attr=CLU):
        llm = Server("LLM Provider\n(OpenAI / Anthropic / Mimo)")
        tav = Server("Tavily\n(Web research)")
        comp = Server("Composio\n(Gmail / Calendar / Meet)")
        jira = Server("Jira / Linear\n(Delivery sync)")

    with Cluster("Lưu trữ (Persistence)", graph_attr=CLU):
        pg = PostgreSQL("PostgreSQL\ncheckpoint + conversations")
        ws = Storage("Workspace\nartifacts/<thread_id>")

    ba >> Edge(label="yêu cầu + tài liệu") >> ui
    pm >> ui
    ui >> Edge(label="tải deliverable", style="dashed") >> cl

    agent >> Edge(label="inference") >> llm
    agent >> Edge(label="≤3 truy vấn/phiên") >> tav
    agent >> Edge(label="gửi mail, đặt lịch") >> comp
    agent >> Edge(label="đồng bộ WBS") >> jira
    agent >> pg
    agent >> ws


# ── H2. Kiến trúc triển khai ──────────────────────────────────────────────────
with d("h2_deployment", "Hình 2 — Kiến trúc triển khai (Deployment / Docker Compose)"):
    dev = Client("Trình duyệt người dùng")
    with Cluster("Docker Compose — project: diagram-agent", graph_attr=CLU):
        with Cluster("service: frontend (nginx:alpine)", graph_attr=CLU):
            fe = Nginx("SPA build (Vite)\ncổng 5173 → 80")
        with Cluster("service: backend (python:3.11-slim)", graph_attr=CLU):
            be = Fastapi("diagram-agent-server\ncổng 8001")
            gv = Python("Graphviz + Playwright\n(render PNG / PDF)")
            be - Edge(style="dotted") - gv
        with Cluster("service: postgres (16-alpine)", graph_attr=CLU):
            db = PostgreSQL("checkpoints, store,\nconversations")
        with Cluster("Volumes", graph_attr=CLU):
            v1 = Storage("./artifacts\n(workspace theo thread)")
            v2 = Storage("agentspace\n(uploads, skills, outputs)")

    dev >> Edge(label="HTTP :5173") >> fe
    fe >> Edge(label="proxy → VITE_BACKEND_URL") >> be
    be >> Edge(label="asyncpg pool (max 20)") >> db
    be >> v1
    be >> v2


# ── H3. Kiến trúc Deep Agent & subagent ───────────────────────────────────────
with d("h3_agent", "Hình 3 — Kiến trúc Deep Agent, middleware và các subagent"):
    req = fc.InputOutput("Yêu cầu người dùng\n+ file đính kèm")

    with Cluster("Middleware pipeline (thứ tự cố định)", graph_attr=CLU):
        m1 = Blank("ContextEditing →\nUsageLogging →\nModelCallLimit")
        m2 = Blank("ToolArgCoercion →\nVisionErrorFallback →\nToolCallLimit")
        m3 = Blank("DrawerReviseGate →\nPhaseToolFilter →\nLLMToolSelector")
        m1 >> Edge(style="dashed") >> m2 >> Edge(style="dashed") >> m3

    main = Rack("MAIN AGENT\n35 tool + 8 filesystem builtin\nRUN_CALL_LIMIT = 80")

    with Cluster("Subagents (5)", graph_attr=CLU):
        s1 = Python("icon_resolver\n7 tool · limit 40")
        s2 = Python("drawer\n8 tool · limit 40")
        s3 = Python("critic\n2 tool · limit 40")
        s4 = Python("wbs_planner\n4 tool · limit 60")
        s5 = Python("ppt_generator\n3 tool · limit 60")

    with Cluster("Skills (progressive disclosure)", graph_attr=CLU):
        sk = Storage("diagrams-as-code · pro-style\nwbs-planning · ppt-generator")

    with Cluster("Trạng thái bền vững", graph_attr=CLU):
        st = Storage("workspace/*.json\n(state machine thực tế)")
        cp = PostgreSQL("LangGraph checkpoint\n+ pending interrupt")

    req >> m1
    m3 >> main
    main >> Edge(label="task(subagent_type=…)") >> s1
    main >> s2
    main >> s3
    main >> s4
    main >> s5
    s2 >> Edge(style="dotted", label="load") >> sk
    main >> Edge(label="đọc/ghi") >> st
    main >> cp


# ── H4. Luồng nghiệp vụ end-to-end với HITL gate ──────────────────────────────
with d("h4_flow", "Hình 4 — Luồng nghiệp vụ end-to-end và các cổng phê duyệt (HITL gates)",
       direction="TB", graph_attr={"splines": "spline", "ranksep": "0.5", "nodesep": "0.4"}):
    root = Blank("")

    with Cluster("A. Tiếp nhận & phân tích (intake)", graph_attr=CLU):
        start = fc.StartEnd("Bắt đầu phiên")
        up = fc.Document("Tải tài liệu yêu cầu\n(PDF / DOCX / MD / TXT)")
        an = fc.Action("analyze_architecture_requirements")
        brief = fc.Action("propose_diagram_brief")
        res = fc.Action("web_research (Tavily, ≤3)")
        g1 = fc.Decision("GATE 1\npropose_tech_stack")
        start >> up >> an >> brief >> res >> g1

    with Cluster("B. Thiết kế & vẽ kiến trúc", graph_attr=CLU):
        g2 = fc.Decision("GATE 2\npropose_blueprint")
        icon = fc.PredefinedProcess("icon_resolver\n→ icon_plan.json")
        draw = fc.PredefinedProcess("drawer\n→ diagram.py, out.png, out.drawio")
        crit = fc.Decision("critic\nPASS / REVISE")
        g3 = fc.Decision("GATE 3\nfinalize_diagram")
        g2 >> icon >> draw >> crit
        crit >> Edge(label="PASS", color=ACCENT) >> g3

    with Cluster("C. Chuỗi deliverable", graph_attr=CLU):
        g4 = fc.Decision("GATE 4\ngenerate_pdf_report")
        g5 = fc.Decision("GATE 5\npropose_wbs_skeleton")
        g6 = fc.Decision("GATE 6\npropose_wbs")
        g7 = fc.Decision("GATE 7\nexport_wbs_excel")
        g8 = fc.Decision("GATE 8\npropose_deck_plan")
        g9 = fc.Decision("GATE 9\ngenerate_ppt_proposal")
        g4 >> g5 >> g6 >> g7 >> g8 >> g9

    with Cluster("D. BRD Agent (module mới) & bàn giao", graph_attr=CLU):
        gb1 = fc.Decision("GATE B1\npropose_brd_outline")
        gb2 = fc.Decision("GATE B2\ngenerate_brd_docx")
        gb3 = fc.Decision("GATE B3\napprove_brd_revision")
        g10 = fc.Decision("GATE 10\nsend_email")
        g11 = fc.Decision("GATE 11\ncreate_client_meeting")
        g12 = fc.Decision("GATE 12\nexport_to_delivery")
        endd = fc.StartEnd("Kết thúc")
        gb1 >> gb2 >> gb3 >> g10 >> g11 >> g12 >> endd

    root >> Edge(style="invis") >> start
    root >> Edge(style="invis") >> g2
    root >> Edge(style="invis") >> g4
    root >> Edge(style="invis") >> gb1

    g1 >> Edge(label="approve", color=ACCENT, constraint="false") >> g2
    g1 >> Edge(label="reject /\nrequest_alternative", style="dashed") >> brief
    crit >> Edge(label="REVISE (≤3 vòng)", style="dashed") >> draw
    g3 >> Edge(label="approve", color=ACCENT, constraint="false") >> g4
    g9 >> Edge(color=ACCENT, constraint="false") >> gb1
    gb3 >> Edge(label="reject →\nsửa 1 section", style="dashed") >> gb2


# ── H5. Vòng đời artifact trong workspace ─────────────────────────────────────
with d("h5_artifacts", "Hình 5 — Vòng đời artifact trong workspace (state machine theo phase)",
       direction="TB", graph_attr={"nodesep": "0.4"}):
    root5 = Blank("")
    with Cluster("Cột 1 — từ yêu cầu tới bản thiết kế", graph_attr=CLU):
        p0 = fc.Document("PHASE intake\nrequirements.md · uploads/*.md")
        p1 = fc.Document("PHASE blueprint\narchitecture_analysis.json\ndiagram_brief.json · tech_stack.json")
        p2 = fc.Document("blueprint.json · render_spec.json\nstyle_plan.json · label_fits.json")
        p0 >> p1 >> p2
    with Cluster("Cột 2 — từ bản vẽ tới deliverable", graph_attr=CLU):
        p3 = fc.Document("PHASE draw\nicon_plan.json → diagram.py\nout.png · out.dot · out.drawio")
        p4 = fc.Document("critique.json · engineer_report.json\nout.native_stats.json")
        p5 = fc.MultipleDocuments("PHASE wbs / report / ppt\nwbs.json → wbs_filled.xlsx\nout.pdf · deck_plan.json → out.pptx")
        p6 = fc.Document("PHASE brd (mới)\nbrd_outline.json · brd_sections/*.json\nout.brd.docx · brd_revisions/REV-n.docx")
        p3 >> p4 >> p5 >> p6
    with Cluster("Sổ cái quản trị (append-only, không ghi đè)", graph_attr=CLU):
        gov = fc.StoredData("solution_model.json (CSM) · approved/REV-n.json\n"
                            "evidence_log.json · decision_log.json\n"
                            "findings_log.json · comment_log.json · usage.json")

    root5 >> Edge(style="invis") >> p0
    root5 >> Edge(style="invis") >> p3
    root5 >> Edge(style="invis") >> gov
    p2 >> Edge(color=ACCENT, constraint="false") >> p3
    p2 >> Edge(style="dotted", label="project", constraint="false") >> gov
    p5 >> Edge(style="dotted", constraint="false") >> gov
    p6 >> Edge(style="dotted", constraint="false") >> gov


# ── H6. Mô hình dữ liệu CSM ───────────────────────────────────────────────────
with d("h6_csm", "Hình 6 — Mô hình dữ liệu chuẩn hoá CSM (Canonical Solution Model)"):
    with Cluster("Lớp yêu cầu (Requirement layer)", graph_attr=CLU):
        r = fc.StoredData("Requirement (REQ)")
        cst = fc.StoredData("Constraint (CON)")
        asm = fc.StoredData("Assumption (ASM)")
    with Cluster("Lớp giải pháp (Solution layer)", graph_attr=CLU):
        dec = fc.StoredData("Decision (DEC)\n+ DecisionOption")
        comp_ = fc.StoredData("Component (COMP)")
        risk = fc.StoredData("Risk (RISK)")
        ctrl = fc.StoredData("Control (CTRL)")
    with Cluster("Lớp thực thi & bằng chứng", graph_attr=CLU):
        wi = fc.StoredData("WorkItem (WBS)")
        ev = fc.StoredData("Evidence (EVD)")
        dl = fc.StoredData("Deliverable (ART)")

    comp_ >> Edge(label="satisfies") >> r
    cst >> Edge(label="constrains") >> dec
    asm >> Edge(label="assumes") >> dec
    dec >> Edge(label="implements") >> comp_
    ctrl >> Edge(label="mitigates") >> risk
    wi >> Edge(label="implements") >> comp_
    ev >> Edge(label="supports") >> dec
    dl >> Edge(label="visualizes") >> comp_
    dl >> Edge(label="claims") >> r


# ── H7. Luồng BRD Agent (module mới) ──────────────────────────────────────────
with d("h7_brd_agent", "Hình 7 — Kiến trúc luồng BRD Agent (module đề xuất)",
       direction="TB", graph_attr={"nodesep": "1.1", "splines": "spline"}):
    root7 = Blank("")
    with Cluster("1. Thu thập ngữ cảnh & lập dàn ý", graph_attr=CLU):
        src = fc.InputOutput("Ngữ cảnh: CSM, blueprint,\ntech_stack, wbs, out.png")
        tpl = fc.Document("BRD template (.docx)\n+ template_map.json")
        t1 = fc.Action("load_brd_context")
        t2 = fc.Action("inspect_brd_template")
        t3 = fc.Action("draft_brd_outline")
        gate1 = fc.Decision("GATE B1\npropose_brd_outline")
        src >> t1
        tpl >> t2
        t1 >> t3
        t2 >> t3
        t3 >> gate1

    with Cluster("2. Soạn nội dung & kết xuất lần đầu", graph_attr=CLU):
        t4 = fc.Action("draft_section_content\n(theo từng section_id)")
        w1 = fc.PredefinedProcess("render_brd_docx\n(điền vào template)")
        w2 = fc.PredefinedProcess("embed_diagram\n(PNG + caption + cross-ref)")
        w3 = fc.Inspection("validate_brd\n(linter cấu trúc + traceability)")
        gate2 = fc.Decision("GATE B2\ngenerate_brd_docx")
        doc = fc.Document("out.brd.docx")
        t4 >> w1 >> w2 >> w3 >> gate2 >> doc

    with Cluster("3. Vòng chỉnh sửa gia tăng (không gen lại toàn bộ)", graph_attr=CLU):
        fb = fc.ManualInput("Phản hồi người dùng\n« sửa mục 4.3 Security »")
        e0 = fc.Action("read_brd_outline\n(bản đồ anchor + checksum)")
        e1 = fc.Action("edit_brd_section\n(patch đúng 1 section)")
        e2 = fc.Action("diff_brd_revision\n(so sánh REV-n vs REV-n+1)")
        gate3 = fc.Decision("GATE B3\napprove_brd_revision")
        outd = fc.StartEnd("Bàn giao\n(email · Jira · package)")
        fb >> e0 >> e1 >> e2 >> gate3 >> outd

    root7 >> Edge(style="invis") >> src
    root7 >> Edge(style="invis") >> t4
    root7 >> Edge(style="invis") >> fb
    gate1 >> Edge(label="approve", color=ACCENT, constraint="false") >> t4
    gate1 >> Edge(label="reject", style="dashed") >> t3
    doc >> Edge(color=ACCENT, constraint="false") >> e0
    gate3 >> Edge(label="reject → lặp lại", style="dashed") >> e1


# ── H8. Cơ chế chỉnh sửa docx tại chỗ ─────────────────────────────────────────
with d("h8_edit_inplace", "Hình 8 — Cơ chế chỉnh sửa .docx tại chỗ theo từng section",
       direction="TB"):
    doc0 = fc.Document("out.brd.docx\n(bản hiện tại)")
    idx = fc.Action("Lập chỉ mục\n(index_document)")
    amap = fc.StoredData("anchor_map.json\nsection_id → (start_idx, end_idx,\nheading_level, checksum)")

    with Cluster("Thao tác vá (patch operations)", graph_attr=CLU):
        p1 = fc.Action("replace_body")
        p2 = fc.Action("replace_table")
        p3 = fc.Action("insert_after")
        p4 = fc.Action("delete_section")
        p5 = fc.Action("set_image")

    guard = fc.Decision("Kiểm tra checksum\n& style contract")
    ooxml = fc.PredefinedProcess("Ghi OOXML tại chỗ\n(python-docx + lxml)")
    doc1 = fc.Document("out.brd.docx\n(bản mới, +1 revision)")
    hist = fc.StoredData("brd_revisions/\nREV-n.docx + patch_log.json")

    doc0 >> idx >> amap
    amap >> p1
    amap >> p2
    amap >> p3
    amap >> p4
    amap >> p5
    p1 >> guard
    p3 >> guard
    p5 >> guard
    guard >> Edge(label="hợp lệ", color=ACCENT) >> ooxml >> doc1
    guard >> Edge(label="xung đột → yêu cầu re-index", style="dashed") >> idx
    doc1 >> Edge(style="dotted") >> hist

print("done")
