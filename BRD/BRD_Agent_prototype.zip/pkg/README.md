# Prototype BRD Agent — bộ mã kèm theo

## Chạy thử

```bash
pip install python-docx diagrams pypdf pillow
apt-get install -y graphviz libreoffice   # để render hình + kiểm tra PDF

python3 make_figs.py      # sinh 8 hình vào figs/
python3 build_brd.py      # điền template.docx -> out/BRD_..._v1.0.docx
python3 toc_rebuild.py    # làm mới cache mục lục bằng số trang thật
python3 demo_edit.py      # BẰNG CHỨNG: sửa đúng 1 mục, phần còn lại không đổi
```

## Vai trò từng tệp

| Tệp | Tương ứng thành phần nào của BRD Agent |
|---|---|
| `docx_edit.py` | `domain/reporting/brd_docx.py` — lớp OOXML: index + 5 patch op + style borrowing |
| `brd_content.py` | đầu ra của tool `draft_section_content` |
| `build_brd.py` | tool `generate_brd_docx` (GATE B2) |
| `toc_rebuild.py` | bước `refresh_toc` bên trong `generate_brd_docx` |
| `demo_edit.py` | tool `edit_brd_section` (GATE B3) + khoá lạc quan |
| `make_figs.py` | subagent `drawer` — diagrams-as-code |

Chi tiết thiết kế: xem `KE_HOACH_BRD_AGENT.md`.
