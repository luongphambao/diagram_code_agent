# -*- coding: utf-8 -*-
"""Bằng chứng cho yêu cầu cốt lõi: SỬA 1 SECTION, PHẦN CÒN LẠI KHÔNG ĐỔI.

Kịch bản mô phỏng đúng những gì BRD Agent sẽ làm khi người dùng nói
« sửa mục 4.3.3 Security, bổ sung yêu cầu về nhật ký kiểm toán ».

Chạy: python3 demo_edit.py
"""
import shutil

import docx_edit as de

SRC = "out/BRD_Diagram_Code_Agent_v1.0.docx"
DST = "out/BRD_Diagram_Code_Agent_v1.1.docx"
TARGET = "security"

shutil.copy(SRC, DST)

# ── Bước 1: agent gọi read_brd_outline → nhận bản đồ anchor + checksum ─────
before = {s["section_id"]: s["checksum"] for s in de.outline(DST)}
sec = next(s for s in de.outline(DST) if s["section_id"] == TARGET)
print(f"Mục cần sửa : {sec['path']}")
print(f"checksum cũ : {sec['checksum']}  ({sec['n_tables']} bảng, "
      f"{sec['n_paragraphs']} đoạn)\n")

# ── Bước 2: agent gọi edit_brd_section với checksum vừa đọc ────────────────
NEW = [
    {"type": "table", "rows": [
        ["Possible threats", "Security requirements", "Safeguards"],
        ["Rò rỉ tài liệu yêu cầu của khách hàng",
         "Dữ liệu phiên phải cô lập theo thread và không rời hạ tầng công ty ngoài phần gửi "
         "tới nhà cung cấp mô hình",
         "Vùng làm việc tách theo thread; chống vượt thư mục; CSDL trong mạng nội bộ"],
        ["Lộ khoá API và khoá tài khoản tích hợp",
         "Khoá bí mật không xuất hiện trong lời nhắc gửi tới mô hình hay trong nhật ký",
         "Khoá truyền qua ngữ cảnh phiên; .env không đưa vào kho mã; che khoá trong nhật ký"],
        ["Người không đủ thẩm quyền phê duyệt cổng trọng yếu",
         "Quyền phê duyệt gắn với vai trò và được cưỡng chế phía máy chủ",
         "Bảng phân quyền theo cổng; nâng từ mức khuyến nghị lên mức cưỡng chế"],
        ["Chèn lệnh độc hại qua tài liệu đính kèm (prompt injection)",
         "Nội dung người dùng cung cấp được đối xử như dữ liệu, không phải chỉ thị",
         "Tách vùng dữ liệu và vùng chỉ thị; vô hiệu hoá thẻ điều khiển; lọc tool theo giai đoạn"],
        ["Sửa đổi tài liệu bàn giao sau khi đã phê duyệt",
         "Mỗi phiên bản đã duyệt phải bất biến và truy vết được",
         "Ảnh chụp phiên bản kèm mã băm; sổ quyết định chỉ-ghi-thêm; nhật ký thao tác vá"],
        ["Không phát hiện được hành vi bất thường sau sự cố  ← BỔ SUNG",
         "Toàn bộ thao tác đọc/ghi artifact và mọi quyết định phê duyệt phải được ghi nhật "
         "ký kiểm toán bất biến, lưu tối thiểu 12 tháng",
         "Nhật ký kiểm toán chỉ-ghi-thêm tách khỏi nhật ký ứng dụng; đồng bộ sang hệ thống "
         "thu thập log tập trung; cảnh báo khi có thao tác vá ngoài giờ làm việc"],
    ], "widths": [1.9, 2.1, 2.4]},
    {"type": "p",
     "text": "Ghi chú: yêu cầu về nhật ký kiểm toán được bổ sung tại phiên bản 1.1 theo "
             "phản hồi của bộ phận An ninh thông tin.", "italic": True},
]

de.replace_section(DST, TARGET, NEW, expect_checksum=sec["checksum"])
print("✓ đã vá mục 4.3.3 Security\n")

# ── Bước 3: kiểm chứng — không mục nào khác bị đụng tới ────────────────────
after = {s["section_id"]: s["checksum"] for s in de.outline(DST)}
changed = [k for k in before if before[k] != after.get(k)]
missing = [k for k in before if k not in after]
added = [k for k in after if k not in before]

print(f"Tổng số mục            : {len(after)}")
print(f"Mục bị thay đổi        : {changed}")
print(f"Mục bị mất / mới thêm  : {missing} / {added}")

# các mục cha chứa mục vừa sửa tất nhiên đổi theo — đó là hành vi đúng
expected = {TARGET, "non-functional-requirements", "system-features-and-non-requirements"}
assert set(changed) <= expected, f"Rò rỉ thay đổi sang: {set(changed) - expected}"
assert not missing and not added
print("\n✓ ĐẠT: chỉ mục được chỉ định (và các mục cha bao ngoài nó) thay đổi.")

# ── Bước 4: thử vá bằng checksum cũ → phải bị từ chối ──────────────────────
try:
    de.replace_section(DST, TARGET, NEW, expect_checksum=sec["checksum"])
    print("✗ LỖI: lẽ ra phải bị từ chối vì checksum đã lệch")
except ValueError as e:
    print(f"✓ ĐẠT: khoá lạc quan chặn ghi đè mù — {str(e)[:90]}…")
